

 create 'covid19' , 'f1'

